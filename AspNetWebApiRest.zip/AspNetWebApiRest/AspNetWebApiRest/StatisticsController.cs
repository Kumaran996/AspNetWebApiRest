﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AspNetWebApiRest.Models;
using Newtonsoft.Json;

namespace AspNetWebApiRest
{
    public class StatisticsController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string fileName = "MOCK_DATA_TU.csv";
            string path = Path.Combine(System.Web.HttpContext.Current.Server.MapPath(@"Data\"), fileName).Replace("\\api", "");
            using (DataTable dt = new DataTable())
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string[] headers = sr.ReadLine().Split(',');
                    foreach (string header in headers)
                    {
                        dt.Columns.Add(header);
                    }
                    while (!sr.EndOfStream)
                    {
                        string[] rows = sr.ReadLine().Split(',');
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < headers.Length; i++)
                        {
                            dr[i] = rows[i];
                        }
                        dt.Rows.Add(dr);
                    }
                }
                string[] Columns = new string[] { "age", "vantageScore", "ficoScore" };
                if (dt.Rows.Count > 0 && dt.Columns.Count > 0)
                {
                    List<Statistics> statistics = new List<Statistics>();
                    foreach (string col in Columns)
                    {
                        Statistics item = new Statistics();
                        item.columnName = col;
                        item.count = dt.AsEnumerable().Select(row => row[col]).Count();
                        item.distinctCount = dt.AsEnumerable().Select(row => row[col]).Distinct().Count();
                        item.min = Convert.ToInt32(dt.AsEnumerable().Select(row => row[col]).Min());
                        item.max = Convert.ToInt32(dt.AsEnumerable().Select(row => row[col]).Max());
                        item.mean = Convert.ToDouble(dt.AsEnumerable().Select(row => Convert.ToInt32(row[col])).Average());
                        item.stddev = GetStandardDeviation((IEnumerable<int>)dt.AsEnumerable().Select(row => Convert.ToInt32(row[col])));
                        statistics.Add(item);
                    }
                    Dictionary<string, Object> NumericDist = new Dictionary<string, Object>();
                    NumericDist.Add("numericDistributions", statistics);
                    Dictionary<string, object> stat = new Dictionary<string, object>();
                    stat.Add("statistics", NumericDist);
                    return Request.CreateResponse(HttpStatusCode.OK, stat);
                }
            }
            return Request.CreateResponse(HttpStatusCode.NotFound);
        }

        public static double GetStandardDeviation(IEnumerable<int> values)
        {
            double avg = values.Average();
            double sum = values.Sum(v => (v - avg) * (v - avg));
            double denominator = values.Count() - 1;
            return denominator > 0.0 ? Math.Sqrt(sum / denominator) : -1;
        }
    }
}